import UIKit
import Lottie
import Zip
import SnapKit

class ViewController: UIViewController {
    
    var bg: UIView!
    var animationView: LottieAnimationView?
    var chooseJson = false
    var shakeUrl: URL?
    
    var animationViewDone: UIImageView!
    var shakeDone: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        ShakeManager.manager.initHapitcEngine()
        view.backgroundColor = UIColor.white
        
        bg = UIView()
        bg.backgroundColor = UIColor.groupTableViewBackground
        view.addSubview(bg)
        bg.snp.makeConstraints { make in
            make.centerX.equalToSuperview()
            make.top.equalTo(40)
            make.size.equalTo(CGSize(width: 300, height: 300))
        }
        
        let button = UIButton(type: .system)
        button.addTarget(self, action: #selector(openDocumentPicker), for: .touchUpInside)
        button.setTitle("选择动画", for: .normal)
        view.addSubview(button)
        button.snp.makeConstraints { make in
            make.centerY.equalToSuperview().offset(100)
            make.centerX.equalToSuperview()
        }
        
        animationViewDone = UIImageView()
        animationViewDone.isHidden = true
        animationViewDone.image = UIImage(named: "Done")
        view.addSubview(animationViewDone)
        animationViewDone.snp.makeConstraints { make in
            make.centerY.equalTo(button)
            make.leading.equalTo(button.snp.trailing).offset(5)
        }
        
        let jsonButton = UIButton(type: .system)
        jsonButton.addTarget(self, action: #selector(openDocumentJsonPicker), for: .touchUpInside)
        jsonButton.setTitle("选择震动", for: .normal)
        view.addSubview(jsonButton)
        jsonButton.snp.makeConstraints { make in
            make.top.equalTo(button.snp.bottom).offset(20)
            make.centerX.equalToSuperview()
        }
        
        shakeDone = UIImageView()
        shakeDone.isHidden = true
        shakeDone.image = UIImage(named: "Done")
        view.addSubview(shakeDone)
        shakeDone.snp.makeConstraints { make in
            make.centerY.equalTo(jsonButton)
            make.leading.equalTo(jsonButton.snp.trailing).offset(5)
        }
        
        let startButton = UIButton(type: .system)
        startButton.addTarget(self, action: #selector(startTest), for: .touchUpInside)
        startButton.setTitle("开始播放", for: .normal)
        view.addSubview(startButton)
        startButton.snp.makeConstraints { make in
            make.top.equalTo(jsonButton.snp.bottom).offset(100)
            make.centerX.equalToSuperview()
        }
        
    }
    
    @objc func openDocumentPicker() {
        chooseJson = false
        animationViewDone.isHidden = true
        // 选择ZIP文件
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [.zip], asCopy: true)
        documentPicker.delegate = self
        documentPicker.modalPresentationStyle = .formSheet
        present(documentPicker, animated: true, completion: nil)
    }
    
    @objc func openDocumentJsonPicker() {
        chooseJson = true
        shakeDone.isHidden = true
        // 选择json文件
        let documentPicker = UIDocumentPickerViewController(forOpeningContentTypes: [.json], asCopy: true)
        documentPicker.delegate = self
        documentPicker.modalPresentationStyle = .formSheet
        present(documentPicker, animated: true, completion: nil)
    }
    
    @objc func startTest() {
        animationView?.play()
        if let shakeUrl = shakeUrl{
            print(shakeUrl)
            let data = try? Data(contentsOf: shakeUrl)
            if data == nil {
                let t = Toast()
                t.show(str: "文件过期,请重新选择文件", on: self.view)
                shakeDone.isHidden = true
                animationViewDone.isHidden = true
                return
            }
            ShakeManager.manager.doCHHapticWithJson(url: shakeUrl)
        }
    }
}

extension ViewController: UIDocumentPickerDelegate {
    
    func documentPicker(_ controller: UIDocumentPickerViewController, didPickDocumentsAt urls: [URL]) {
        guard let zipFileURL = urls.first else { return }
        if chooseJson{
            shakeUrl = zipFileURL
            shakeDone.isHidden = false
        }else{
            print("选中的ZIP文件路径：\(zipFileURL.path)")
            // 检查文件扩展名是否为 .zip
            if zipFileURL.pathExtension.lowercased() != "zip" {
                print("请选择一个有效的ZIP文件")
                return
            }
            // 解压ZIP文件
            unzipFile(at: zipFileURL)
        }
    }
    
    func documentPickerWasCancelled(_ controller: UIDocumentPickerViewController) {
        print("Document Picker was cancelled")
    }
    
    // 解压ZIP文件
    func unzipFile(at zipFileURL: URL) {
        do {
            // 获取解压后文件的路径
           let destinationURL = try Zip.quickUnzipFile(zipFileURL)
           print("ZIP文件已解压到：\(destinationURL.path)")
           
           // 如果解压后的文件夹包含一个额外的文件夹，获取该文件夹路径
           let fileManager = FileManager.default
           let contents = try fileManager.contentsOfDirectory(at: destinationURL, includingPropertiesForKeys: nil)
           
            let maxosContents = contents.first(where: { $0.lastPathComponent == "__MACOSX" })
            let filteredContents = contents.first(where: { $0.lastPathComponent != "__MACOSX" })
            
           // 检查目标路径是否包含一个额外的文件夹
           let unzippedFolderURL: URL
           if maxosContents != nil, let folderURL = filteredContents, folderURL.hasDirectoryPath {
               // 如果解压后的目录里只有一个文件夹，进入该文件夹
               unzippedFolderURL = folderURL
               print("找到内部文件夹：\(folderURL.path)")
           } else {
               // 如果没有额外的文件夹，直接使用解压的路径
               unzippedFolderURL = destinationURL
           }
           
           // 查找解压后的JSON文件
           let files = try fileManager.contentsOfDirectory(at: unzippedFolderURL, includingPropertiesForKeys: nil)
           let jsonFiles = files.filter { $0.pathExtension.lowercased() == "json" }
            
            // 尝试加载第一个JSON文件
            for jsonFileURL in jsonFiles {
                if let animation = LottieAnimation.filepath(jsonFileURL.path) {
                    print("成功加载动画：\(jsonFileURL.lastPathComponent)")
                    
                    // 获取图片资源目录
                    let imagesPath = unzippedFolderURL.path + "/images"
                    let imageProvider = LottieImageProvider(imagesDirectory: imagesPath)
                    
                    if animationView != nil {
                        animationView?.removeFromSuperview()
                    }
                    
                    // 创建动画视图
                    animationView = LottieAnimationView(animation: animation)
                    animationView?.imageProvider = imageProvider
                    
                    // 设置动画视图的大小和其他属性
                    animationView?.frame = CGRect(x: 0, y: 0, width: 300, height: 300)
                    animationView?.contentMode = .scaleAspectFit
                    bg.addSubview(animationView!)
                    
                    animationViewDone.isHidden = false
//                    // 播放动画
//                    animationView?.play()
                    
                    // 找到有效的JSON文件后，退出循环
                    return
                }
            }
            
            let t = Toast()
            t.show(str: "没有找到有效的Lottie动画文件", on: self.view)
        } catch {
            let t = Toast()
            t.show(str: "解压文件时出错", on: self.view)
            print("解压文件时出错: \(error)")
        }
    }
}

class LottieImageProvider: AnimationImageProvider {
    
    private var imagesDirectory: String
    
    init(imagesDirectory: String) {
        self.imagesDirectory = imagesDirectory
    }
    
    func imageForAsset(asset: Lottie.ImageAsset) -> CGImage? {
        let imagePath = "\(imagesDirectory)/\(asset.name)"
        print("加载图片资源: \(imagePath)")  // 添加打印日志
        if let image = UIImage(contentsOfFile: imagePath) {
            return image.cgImage
        } else {
            print("无法加载图片资源: \(imagePath)")  // 错误日志
            return nil
        }
    }
}

class Toast: UIView{
    
    var titleLabel: UILabel!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        
        backgroundColor = UIColor.black.withAlphaComponent(0.5)
        layer.cornerRadius = 5
        
        titleLabel = UILabel()
        titleLabel.textColor = UIColor.white
        titleLabel.numberOfLines = 0
        addSubview(titleLabel)
        titleLabel.snp.makeConstraints { make in
            make.top.equalTo(20)
            make.leading.equalTo(20)
            make.trailing.equalToSuperview().offset(-20)
            make.bottom.equalToSuperview().offset(-20)
        }
    }
    
    required init?(coder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func show(str: String,on view: UIView){
        titleLabel.text = str
        view.addSubview(self)
        self.snp.makeConstraints { make in
            make.center.equalToSuperview()
        }
        
        DispatchQueue.main.asyncAfter(deadline: DispatchTime.now() + 2) {
            self.removeFromSuperview()
        }
    }
}
