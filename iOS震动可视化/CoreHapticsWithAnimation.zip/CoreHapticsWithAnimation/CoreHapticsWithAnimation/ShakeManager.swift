//
//  STShakeManager.swift
//  Stretch
//
//  Created by wl on 2023/10/11.
//

import Foundation
import CoreHaptics
import AudioToolbox
import UIKit
import SwiftyJSON

@objc class ShakeManager: NSObject{
    
    @objc static let manager = ShakeManager()
    
    var hapticEngine: CHHapticEngine?
    
    //MARK: public
    @objc func initHapitcEngine(){
        do {
            hapticEngine = try CHHapticEngine()
        }catch{
            
        }
    }
    
    ///json文件震动
    @objc func doCHHapticWithJson(url: URL){
        do {
            if #available(iOS 13.0, *){
                if #available(iOS 16.0, *) {
                    let pattern = try CHHapticPattern(contentsOf: url)
                    doCHHapticWithPattern(pattern: pattern)
                } else {
                    guard let events = parseEventFormJsonUrl(url: url) else { return}
                    if events.count == 0 { return }
                    let pattern = try CHHapticPattern(events: events, parameterCurves: [])
                    doCHHapticWithPattern(pattern: pattern)
                }
            }
        } catch let e {
            print(e)
        }
    }
    
    ///json文件震动
    @objc func doCHHapticWithJson(name: String){
        do {
            if #available(iOS 13.0, *){
                if #available(iOS 16.0, *) {
                    guard let url = Bundle.main.url(forResource: name, withExtension: ".json") else { return }
                    let pattern = try CHHapticPattern(contentsOf: url)
                    doCHHapticWithPattern(pattern: pattern)
                } else {
                    guard let events = parseEventFormJson(name: name) else { return}
                    if events.count == 0 { return }
                    let pattern = try CHHapticPattern(events: events, parameterCurves: [])
                    doCHHapticWithPattern(pattern: pattern)
                }
            }
        } catch let e {
            print(e)
        }
    }
    
    private func parseEventFormJsonUrl(url: URL) -> [CHHapticEvent]?{
        guard let jsonData = try? Data(contentsOf: url) else { return nil }
        return parseEventFormJsonData(jsonData: jsonData)
    }
    
    private func parseEventFormJson(name: String) -> [CHHapticEvent]?{
        let path = Bundle.main.path(forResource: name, ofType: ".json")
        guard let path = path else { return nil }
        guard let jsonData = try? Data(contentsOf: URL(fileURLWithPath: path)) else { return nil }
        return parseEventFormJsonData(jsonData: jsonData)
    }
    
    private func parseEventFormJsonData(jsonData: Data) -> [CHHapticEvent]?{
        guard let jsonStr = String(data: jsonData, encoding: .utf8) else {
            return nil
        }
        let json = JSON(parseJSON: jsonStr)
        var events = [CHHapticEvent]()
        for e in json["Pattern"].arrayValue{
            var event: CHHapticEvent?
            let eventData = e["Event"]
            //震动类型
            let eventType = eventData["EventType"].stringValue
            //震动时间点
            let time = TimeInterval(eventData["Time"].doubleValue)
            //持续时间
            let duration = TimeInterval(eventData["EventDuration"].doubleValue)
            //震动强度锐度
            var parameters = [CHHapticEventParameter]()
            for param in eventData["EventParameters"].arrayValue{
                let paramType = param["ParameterID"].stringValue
                let value = param["ParameterValue"].floatValue
                if paramType == "HapticIntensity"{
                    let p = CHHapticEventParameter(parameterID: .hapticIntensity, value: value)
                    parameters.append(p)
                }else{
                    let p = CHHapticEventParameter(parameterID: .hapticSharpness, value: value)
                    parameters.append(p)
                }
            }
            if eventType == "HapticContinuous" {
                //连续的
                event = CHHapticEvent(eventType: .hapticContinuous,
                                            parameters: parameters,
                                            relativeTime: time,
                                            duration: duration)
            }else{
                //短促的
                event = CHHapticEvent(eventType: .hapticTransient,
                                      parameters: parameters,
                                      relativeTime: time)
            }
            if let event = event{
                events.append(event)
            }
        }
        
        return events
    }
    
    ///自定义震动
    @objc private func doCHHapticWithPattern(pattern: CHHapticPattern){
        do {
            if #available(iOS 13.0, *){
                let player = try hapticEngine?.makePlayer(with: pattern)
                try hapticEngine?.start()
                try player?.start(atTime: CHHapticTimeImmediate)
            }
        } catch let e {
            print(e)
        }
    }
    
    private func supportCHHaptic() -> Bool{
        var deviceSupport = false
        let model = UIDevice.current.modelID
        if let e = model.firstIndex(of: "e"),
           let sperator = model.firstIndex(of: ","){
            var num = model[e..<sperator]
            num = num.suffix(num.count - 1)
            //iPhone8 以后支持CoreHaptics
            if Int(num) ?? 0 >= 10 {
                deviceSupport = true
            }
        }
        
        if #available(iOS 13.0, *){
            if deviceSupport {
                return true
            }else{
                return false
            }
        }else{
            return false
        }
    }
}

extension UIDevice {
    
    var modelID: String{
        var systemInfo = utsname()
        uname(&systemInfo)
        let machineMirror = Mirror(reflecting: systemInfo.machine)
        let identifier = machineMirror.children.reduce("") { identifier, element in
            guard let value = element.value as? Int8, value != 0 else { return identifier }
            return identifier + String(UnicodeScalar(UInt8(value)))
        }
        return identifier
    }
}
