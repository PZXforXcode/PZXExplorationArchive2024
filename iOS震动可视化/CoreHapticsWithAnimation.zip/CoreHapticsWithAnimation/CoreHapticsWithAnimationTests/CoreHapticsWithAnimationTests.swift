//
//  CoreHapticsWithAnimationTests.swift
//  CoreHapticsWithAnimationTests
//
//  Created by UEDer1 on 11/14/24.
//

import Testing
@testable import CoreHapticsWithAnimation

struct CoreHapticsWithAnimationTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
