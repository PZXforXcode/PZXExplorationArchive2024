# 动画与震动文件导入
## 震动文件
* 震动文件导出后一般为一个json文件,直接保存到iPhone->文件app中

## Lottie动画文件
* Lottie动画文件一般为一个json文件,和图片资源文件夹,将图片资源文件夹命名为images,将json文件和图片资源文件夹放入一个文件夹
* 将文件夹压缩成zip格式
* 保存到iPhone->文件app中
* 层级如下 <br/>
![动画文件层级](https://qiniu.apk.cq-wnl.com/shakecengji.jpg)

# 使用
* 启动app,依次选中.zip文件和对应的震动json文件,点击开始播放
